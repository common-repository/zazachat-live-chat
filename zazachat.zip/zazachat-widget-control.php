 <p>
<label for="zazachat_clientid">ZaZaChat Account # <input name="zazachat_clientid"
type="text" value="<?php echo $zazachat_clientid; ?>" /></label></p>
<p><label for="zazachat_buttonid">ZaZaChat Button # <input name="zazachat_buttonid"
type="text" value="<?php echo $zazachat_buttonid; ?>" /></label></p>
<p><label for="zazachat_title">ZaZaChat Title <input name="zazachat_title"
type="text" value="<?php echo $zazachat_title; ?>" /></label></p>


<p><input type="hidden" id="zazachat_submit" name="zazachat_submit" value="1" />
<img src='http://www.zazachat.com/livechatclient/images/ZaZaChat_logo.gif' border=0><br /><a href='https://www.zazachat.com/newaccount/' target='_new' style='font-size:14px; font-weight:bold;text-decoration:none;'><b>Get ZaZaChat account</b></a><br /><a href="http://www.zazachat.com/live-chat-buttons.htm" target='_blank' style='font-size:14px;text-decoration:none;'>See available Live chat buttons</a>
</p>
